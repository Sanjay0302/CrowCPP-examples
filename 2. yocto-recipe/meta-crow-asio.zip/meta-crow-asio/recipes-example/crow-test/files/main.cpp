#include "crow.h"

int main()
{
    crow::SimpleApp app;

    CROW_ROUTE(app, "/")([](){
        return "Hello World! Crow C++ is working with ASIO!";
    });

    CROW_ROUTE(app, "/json")([]{
        crow::json::wvalue x;
        x["message"] = "Hello from Crow with ASIO!";
        x["framework"] = "Crow C++";
        x["networking"] = "ASIO";
        return x;
    });

    CROW_ROUTE(app, "/health")([]{
        return "OK";
    });

    app.port(8080).multithreaded().run();
    return 0;
}
